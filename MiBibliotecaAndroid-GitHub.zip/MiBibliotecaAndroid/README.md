# Mi Biblioteca

Proyecto Android inicial de una biblioteca local y offline.

## Funciones incluidas
- Categorías: Series / Anime, Películas y Otros.
- Añadir elementos y una carpeta opcional.
- Elegir portadas manualmente desde el teléfono.
- Vincular un vídeo local y abrirlo con otra aplicación.
- Guardar el catálogo básico en el dispositivo.

## Compilar
Abre el proyecto con Android Studio y ejecuta la tarea `:app:assembleDebug`.
El APK de depuración se genera en `app/build/outputs/apk/debug/app-debug.apk`.

Este es un prototipo inicial: todavía no incluye gestión completa de temporadas y episodios.
