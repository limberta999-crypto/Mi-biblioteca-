package com.mibiblioteca.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject

private data class LibraryItem(
    val id: Long,
    val title: String,
    val category: String,
    val cover: String = "",
    val file: String = "",
    val folder: String = ""
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LibraryApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LibraryApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("library", 0) }
    val items = remember {
        mutableStateListOf<LibraryItem>().apply {
            val raw = prefs.getString("items", "[]") ?: "[]"
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                add(LibraryItem(o.optLong("id"), o.optString("title"),
                    o.optString("category"), o.optString("cover"),
                    o.optString("file"), o.optString("folder")))
            }
        }
    }
    fun persist() {
        val arr = JSONArray()
        items.forEach { item ->
            arr.put(JSONObject().put("id", item.id).put("title", item.title)
                .put("category", item.category).put("cover", item.cover)
                .put("file", item.file).put("folder", item.folder))
        }
        prefs.edit().putString("items", arr.toString()).apply()
    }

    var category by remember { mutableStateOf("Series / Anime") }
    var title by remember { mutableStateOf("") }
    var folder by remember { mutableStateOf("") }
    var coverTarget by remember { mutableStateOf<Long?>(null) }
    var selected by remember { mutableStateOf<LibraryItem?>(null) }
    var showAdd by remember { mutableStateOf(false) }

    val coverPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            val index = items.indexOfFirst { it.id == coverTarget }
            if (index >= 0) {
                items[index] = items[index].copy(cover = uri.toString())
                persist()
            }
        }
        coverTarget = null
    }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && selected != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            val index = items.indexOfFirst { it.id == selected!!.id }
            if (index >= 0) {
                items[index] = items[index].copy(file = uri.toString())
                selected = items[index]
                persist()
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Color(0xFF090A0E), surface = Color(0xFF171922),
        primary = Color(0xFFE3B56B), onBackground = Color(0xFFF4F1EA),
        onSurface = Color(0xFFF4F1EA)
    )) {
        Scaffold(
            containerColor = Color(0xFF090A0E),
            topBar = {
                TopAppBar(
                    title = { Text("MI BIBLIOTECA", fontWeight = FontWeight.Black) },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF090A0E))
                )
            },
            floatingActionButton = {
                FloatingActionButton(onClick = { showAdd = true }, containerColor = Color(0xFFE3B56B), contentColor = Color.Black) {
                    Text("+", style = MaterialTheme.typography.headlineMedium)
                }
            }
        ) { padding ->
            Column(Modifier.padding(padding).fillMaxSize().padding(horizontal = 16.dp)) {
                Text("Tu colección, sin conexión.", color = Color.LightGray)
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Series / Anime", "Películas", "Otros").forEach { name ->
                        FilterChip(selected = category == name, onClick = { category = name }, label = { Text(name) })
                    }
                }
                Spacer(Modifier.height(12.dp))
                val visible = items.filter { it.category == category }
                if (visible.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Todavía no hay elementos.\nPulsa + para añadir uno.", color = Color.Gray)
                    }
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(visible, key = { it.id }) { item ->
                            Card(
                                modifier = Modifier.fillMaxWidth().clickable { selected = item },
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF171922)),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Column(Modifier.padding(16.dp)) {
                                    Text(item.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                    Text(item.folder.ifBlank { item.category }, color = Color.LightGray)
                                    if (item.cover.isNotBlank()) Text("Portada añadida", color = Color(0xFFE3B56B))
                                    if (item.file.isNotBlank()) Text("Archivo vinculado", color = Color(0xFFE3B56B))
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        TextButton(onClick = { coverTarget = item.id; coverPicker.launch(arrayOf("image/*")) }) { Text("Cambiar portada") }
                                        TextButton(onClick = { selected = item }) { Text("Abrir ficha") }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAdd) {
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("Añadir a mi biblioteca") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Nombre") }, singleLine = true)
                    OutlinedTextField(value = folder, onValueChange = { folder = it }, label = { Text("Carpeta (opcional)") }, singleLine = true)
                    Text("Categoría: $category", color = Color.Gray)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (title.isNotBlank()) {
                        items.add(LibraryItem(System.currentTimeMillis(), title.trim(), category, folder = folder.trim()))
                        persist()
                        title = ""; folder = ""; showAdd = false
                    }
                }) { Text("Añadir") }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Cancelar") } }
        )
    }

    selected?.let { item ->
        AlertDialog(
            onDismissRequest = { selected = null },
            title = { Text(item.title) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Puedes vincular un archivo guardado en tu teléfono.")
                    Text(if (item.file.isBlank()) "Aún no hay archivo vinculado." else "Archivo vinculado.")
                }
            },
            confirmButton = {
                TextButton(onClick = { filePicker.launch(arrayOf("video/*")); }) { Text("Elegir video") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = {
                        val uri = Uri.parse(item.file)
                        if (item.file.isNotBlank()) {
                            context.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "video/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                        }
                    }, enabled = item.file.isNotBlank()) { Text("Reproducir externo") }
                    TextButton(onClick = { selected = null }) { Text("Cerrar") }
                }
            }
        )
    }
}
